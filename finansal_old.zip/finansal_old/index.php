\
<?php
require_once __DIR__ . '/config.php';
startSecureSession();

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$user_name = $_SESSION['user_name'] ?? 'MR HASAR ADMIN';
$user_role = $_SESSION['user_role'] ?? 'ADMIN';

$stats = [
  'toplam_dosya' => 0,
  'aktif_dosya' => 0,
  'kapali_dosya' => 0,
  'adk_dosya' => 0,
  'bedeni_hasar' => 0,
  'aylik_gelir' => 0,
];

$recent_cases = [];
?>
<!DOCTYPE html>
<html lang="tr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>MR HASAR DANIŞMANLIK - KONTROL PANELİ</title>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
  <style>
    :root { --bg-main:#0b1324; --text:#eaf0ff; --muted:#9fb3d9; --primary:#2f80ff; --danger:#f31260; --border:rgba(255,255,255,0.08); --shadow:0 10px 30px rgba(0,0,0,0.35); --radius:16px; }
    * { box-sizing: border-box; }
    body{ margin:0; font-family:"Segoe UI",system-ui,-apple-system,Arial; background: linear-gradient(180deg,#061027,#0b1324 40%,#061027); color: var(--text); }
    .topbar{ position:sticky; top:0; z-index:10; background: rgba(10,20,40,0.75); backdrop-filter: blur(10px); border-bottom:1px solid var(--border); padding:14px 18px; display:flex; align-items:center; justify-content:space-between; }
    .brand{display:flex;flex-direction:column;gap:4px;}
    .brand .title{font-weight:800;letter-spacing:0.6px;color:#3aa0ff;}
    .brand .slogan{font-size:11px;letter-spacing:1px;color:#ffb020;opacity:0.9;font-weight:700;}
    .userbox{display:flex;gap:12px;align-items:center;font-size:12px;color:var(--muted);}
    .logout{ background: var(--danger); color:white; border:none; padding:8px 12px; border-radius:10px; cursor:pointer; font-weight:700; }
    .nav{ display:flex; gap:14px; padding:10px 18px; border-bottom:1px solid var(--border); background: rgba(10,20,40,0.45); overflow:auto; white-space:nowrap; }
    .nav a{ color:var(--muted); text-decoration:none; padding:10px 12px; border-radius:12px; font-weight:700; font-size:12px; border:1px solid transparent; }
    .nav a.active{ color:var(--text); background: rgba(47,128,255,0.15); border-color: rgba(47,128,255,0.35); }
    .wrap{padding:18px;max-width:1400px;margin:0 auto;}
    .section-title{display:flex;gap:10px;align-items:center;font-size:16px;font-weight:900;margin:8px 0 16px;}
    .cards{display:grid;grid-template-columns: repeat(6, minmax(160px, 1fr));gap:14px;}
    @media (max-width:1200px){.cards{ grid-template-columns: repeat(3, 1fr); }}
    @media (max-width:720px){.cards{ grid-template-columns: repeat(2, 1fr); }}
    .card{ background: linear-gradient(180deg, rgba(255,255,255,0.06), rgba(255,255,255,0.02)); border:1px solid var(--border); border-radius: var(--radius); box-shadow: var(--shadow); padding:14px; display:flex; align-items:center; justify-content:space-between; min-height:86px; }
    .card .left{display:flex;gap:12px;align-items:center;}
    .icon{width:40px;height:40px;border-radius:14px;display:grid;place-items:center;font-size:16px;color:white;}
    .k1{ background: rgba(47,128,255,0.85); } .k2{ background: rgba(23,201,100,0.85); } .k3{ background: rgba(245,165,36,0.85); } .k4{ background: rgba(128,90,213,0.85); } .k5{ background: rgba(0,190,214,0.85); } .k6{ background: rgba(0,180,90,0.85); }
    .meta{display:flex;flex-direction:column;gap:6px;}
    .meta .label{font-size:11px;color: var(--muted);font-weight:800;letter-spacing:0.4px;}
    .meta .val{font-size:20px;font-weight:900;color: var(--text);}
    .actions{margin-top:14px;display:grid;grid-template-columns: 1fr 1fr 1fr 1fr;gap:14px;}
    @media (max-width:1000px){.actions{ grid-template-columns: 1fr 1fr; }}
    .btn{ border:none;border-radius: 14px;padding:14px 16px;color:white;font-weight:900;cursor:pointer; display:flex;align-items:center;justify-content:center;gap:10px;letter-spacing:0.2px;box-shadow: var(--shadow); }
    .b1{ background: linear-gradient(90deg, #1bbf7a, #1aa6ff); } .b2{ background: linear-gradient(90deg, #7b61ff, #49a3ff); } .b3{ background: linear-gradient(90deg, #ff9f1c, #ff6a00); } .b4{ background: rgba(255,255,255,0.06); border:1px solid var(--border); color: var(--text); }
    .panel{margin-top:18px;background: rgba(255,255,255,0.03);border:1px solid var(--border);border-radius: var(--radius);padding:14px;}
    .panel-head{display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;}
    .panel-head .h{display:flex;align-items:center;gap:10px;font-weight:900;}
    .panel-head .all{ color:var(--muted);font-weight:800;font-size:12px;border:1px solid var(--border); padding:8px 10px;border-radius: 12px;background: rgba(255,255,255,0.03);text-decoration:none; }
    table{width:100%;border-collapse:separate;border-spacing:0;overflow:hidden;border-radius: 14px;border:1px solid var(--border);}
    th, td{padding:12px 10px;font-size:12px;border-bottom:1px solid rgba(255,255,255,0.06);}
    th{ background: rgba(255,255,255,0.04);color: var(--muted); text-transform:uppercase;font-weight:900;letter-spacing:0.3px; }
    td{color: #dce7ff;}
    .empty{padding:40px 10px;text-align:center;color: var(--muted);font-weight:800;}
  </style>
</head>
<body>
  <div class="topbar">
    <div class="brand">
      <div class="title">MR HASAR DANIŞMANLIK</div>
      <div class="slogan"><?= htmlspecialchars(APP_SLOGAN) ?></div>
    </div>
    <div class="userbox">
      <div>
        <div style="font-weight:900;color:#fff;"><?= htmlspecialchars($user_name) ?></div>
        <div style="text-transform:uppercase;"><?= htmlspecialchars($user_role) ?></div>
      </div>
      <form action="logout.php" method="post">
        <button class="logout" type="submit"><i class="fa-solid fa-right-from-bracket"></i> ÇIKIŞ</button>
      </form>
    </div>
  </div>

  <div class="nav">
    <a class="active" href="index.php"><i class="fa-solid fa-house"></i> ANASAYFA</a>
    <a href="dosyalar.php"><i class="fa-solid fa-folder-open"></i> DOSYA İŞLEMLERİ</a>
    <a href="ortaklar.php"><i class="fa-solid fa-users"></i> ORTAKLAR</a>
    <a href="raporlar.php"><i class="fa-solid fa-chart-line"></i> RAPORLAR</a>
    <a href="hesaplama.php"><i class="fa-solid fa-calculator"></i> HESAPLAMA</a>
    <a href="tanimlamalar.php"><i class="fa-solid fa-sliders"></i> TANIMLAMALAR</a>
    <a href="muhasebe.php"><i class="fa-solid fa-coins"></i> MUHASEBE</a>
    <a href="sistem.php"><i class="fa-solid fa-gear"></i> SİSTEM</a>
    <a href="dilekceler.php"><i class="fa-solid fa-file-lines"></i> DİLEKÇELER</a>
    <a href="mesajlar.php"><i class="fa-solid fa-envelope"></i> MESAJLAR</a>
    <a href="ajanda.php"><i class="fa-solid fa-calendar-days"></i> AJANDA</a>
  </div>

  <div class="wrap">
    <div class="section-title"><i class="fa-solid fa-gauge-high"></i> KONTROL PANELİ</div>

    <div class="cards">
      <div class="card"><div class="left"><div class="icon k1"><i class="fa-solid fa-folder"></i></div><div class="meta"><div class="label">TOPLAM DOSYA</div><div class="val"><?= (int)$stats['toplam_dosya'] ?></div></div></div></div>
      <div class="card"><div class="left"><div class="icon k2"><i class="fa-solid fa-circle-check"></i></div><div class="meta"><div class="label">AKTİF DOSYA</div><div class="val"><?= (int)$stats['aktif_dosya'] ?></div></div></div></div>
      <div class="card"><div class="left"><div class="icon k3"><i class="fa-solid fa-clock"></i></div><div class="meta"><div class="label">KAPALI DOSYA</div><div class="val"><?= (int)$stats['kapali_dosya'] ?></div></div></div></div>
      <div class="card"><div class="left"><div class="icon k4"><i class="fa-solid fa-car-burst"></i></div><div class="meta"><div class="label">ADK DOSYA</div><div class="val"><?= (int)$stats['adk_dosya'] ?></div></div></div></div>
      <div class="card"><div class="left"><div class="icon k5"><i class="fa-solid fa-user-injured"></i></div><div class="meta"><div class="label">BEDENİ HASAR</div><div class="val"><?= (int)$stats['bedeni_hasar'] ?></div></div></div></div>
      <div class="card"><div class="left"><div class="icon k6"><i class="fa-solid fa-sterling-sign"></i></div><div class="meta"><div class="label">AYLIK GELİR</div><div class="val">₺<?= number_format((float)$stats['aylik_gelir'], 0, ',', '.') ?></div></div></div></div>
    </div>

    <div class="actions">
      <button class="btn b1" onclick="location.href='dosya_ekle.php'"><i class="fa-solid fa-plus"></i> YENİ DOSYA</button>
      <button class="btn b2" onclick="location.href='dosyalar.php'"><i class="fa-solid fa-folder-tree"></i> DOSYALAR</button>
      <button class="btn b3" onclick="location.href='crm.php'"><i class="fa-solid fa-headset"></i> CRM</button>
      <button class="btn b4" onclick="location.href='raporlar.php'"><i class="fa-solid fa-chart-pie"></i> RAPORLAR</button>
    </div>

    <div class="panel">
      <div class="panel-head">
        <div class="h"><i class="fa-solid fa-rotate-left"></i> SON DOSYALAR</div>
        <a class="all" href="dosyalar.php"><i class="fa-solid fa-list"></i> TÜMÜNÜ GÖR</a>
      </div>

      <table>
        <thead>
          <tr>
            <th>DOSYA NO</th>
            <th>T.C.</th>
            <th>ADI SOYADI</th>
            <th>TÜR</th>
            <th>SİGORTA</th>
            <th>AŞAMA</th>
            <th>SORUMLU</th>
            <th>TARİH</th>
            <th>İŞLEM</th>
          </tr>
        </thead>
        <tbody>
          <?php if (empty($recent_cases)): ?>
            <tr><td class="empty" colspan="9"><i class="fa-solid fa-folder-open"></i><br>HENÜZ DOSYA BULUNMUYOR</td></tr>
          <?php else: ?>
            <?php foreach ($recent_cases as $c): ?>
              <tr>
                <td><?= htmlspecialchars((string)$c['dosya_no']) ?></td>
                <td><?= htmlspecialchars((string)$c['tc_no']) ?></td>
                <td><?= htmlspecialchars((string)$c['ad_soyad']) ?></td>
                <td><?= htmlspecialchars((string)$c['tur']) ?></td>
                <td><?= htmlspecialchars((string)$c['sigorta']) ?></td>
                <td><?= htmlspecialchars((string)$c['asama']) ?></td>
                <td><?= htmlspecialchars((string)$c['sorumlu']) ?></td>
                <td><?= htmlspecialchars((string)$c['tarih']) ?></td>
                <td><a class="all" href="dosya_detay.php?id=<?= (int)$c['id'] ?>">AÇ</a></td>
              </tr>
            <?php endforeach; ?>
          <?php endif; ?>
        </tbody>
      </table>
    </div>

  </div>
</body>
</html>

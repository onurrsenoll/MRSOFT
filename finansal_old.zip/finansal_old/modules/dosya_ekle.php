<?php
/**
 * MR HASAR DANIŞMANLIK - YENİ DOSYA EKLE
 * EXCELLENCE DISTINGUISHES US ALWAYS
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../config.php';

$error = '';
$success = '';

try {
    $db = getDB();
    
    // Sigorta şirketlerini getir
    $stmt = $db->query("SELECT id, name FROM insurers WHERE is_active = 1 ORDER BY name");
    $sigortalar = $stmt->fetchAll();
    
    // Aşamaları getir
    $stmt = $db->query("SELECT id, name FROM stage_definitions WHERE is_active = 1 ORDER BY sort_order");
    $asamalar = $stmt->fetchAll();
    
    // Avukatları getir
    $stmt = $db->query("SELECT id, full_name FROM users WHERE role = 'AVUKAT' AND is_active = 1");
    $avukatlar = $stmt->fetchAll();
    
    // Sorumluları getir
    $stmt = $db->query("SELECT id, full_name FROM users WHERE is_active = 1 ORDER BY full_name");
    $sorumlular = $stmt->fetchAll();
    
} catch (Exception $e) {
    $error = 'VERİTABANI HATASI: ' . $e->getMessage();
    $sigortalar = [];
    $asamalar = [];
    $avukatlar = [];
    $sorumlular = [];
}

// Form gönderildi
if ($_SERVER['REQUEST_METHOD'] === 'POST' && empty($error)) {
    $case_type = $_POST['case_type'] ?? '';
    $tc_kimlik = preg_replace('/[^0-9]/', '', $_POST['tc_kimlik'] ?? '');
    $ad_soyad = trim(mb_strtoupper($_POST['ad_soyad'] ?? '', 'UTF-8'));
    $telefon = trim($_POST['telefon'] ?? '');
    $kaza_tarihi = $_POST['kaza_tarihi'] ?? '';
    $plaka = trim(mb_strtoupper($_POST['plaka'] ?? '', 'UTF-8'));
    $karsi_plaka = trim(mb_strtoupper($_POST['karsi_plaka'] ?? '', 'UTF-8'));
    $davali_sirket_id = intval($_POST['davali_sirket_id'] ?? 0);
    $sigorta_hasar_no = trim($_POST['sigorta_hasar_no'] ?? '');
    $current_stage_id = intval($_POST['current_stage_id'] ?? 0) ?: null;
    $source_type = $_POST['source_type'] ?? '';
    $source_name = trim(mb_strtoupper($_POST['source_name'] ?? '', 'UTF-8'));
    $sorumlu_user_id = intval($_POST['sorumlu_user_id'] ?? $_SESSION['user_id']);
    $assigned_lawyer_user_id = intval($_POST['assigned_lawyer_user_id'] ?? 0) ?: null;
    
    // Doğrulama
    if (empty($case_type)) {
        $error = 'DOSYA TÜRÜ SEÇİNİZ';
    } elseif (strlen($tc_kimlik) != 11) {
        $error = 'T.C. KİMLİK NO 11 HANELİ OLMALIDIR';
    } elseif (empty($ad_soyad)) {
        $error = 'ADI SOYADI GİRİNİZ';
    } elseif (empty($telefon)) {
        $error = 'TELEFON GİRİNİZ';
    } elseif (empty($kaza_tarihi)) {
        $error = 'KAZA TARİHİ GİRİNİZ';
    } elseif ($davali_sirket_id == 0) {
        $error = 'SİGORTA ŞİRKETİ SEÇİNİZ';
    } elseif ($case_type == 'ADK' && (empty($plaka) || empty($karsi_plaka))) {
        $error = 'ADK DOSYASI İÇİN PLAKA VE KARŞI PLAKA ZORUNLUDUR';
    } elseif (empty($source_type)) {
        $error = 'DOSYA KAYNAĞI SEÇİNİZ';
    } else {
        try {
            $db->beginTransaction();
            
            // Dosya numarası oluştur
            $dosya_no = generateDosyaNo();
            
            // Ana dosya kaydı
            $stmt = $db->prepare("
                INSERT INTO cases (dosya_no, case_type, tc_kimlik, ad_soyad, telefon, kaza_tarihi, 
                    plaka, karsi_plaka, davali_sirket_id, sigorta_hasar_no, current_stage_id,
                    acilis_tarihi, source_type, source_name, sorumlu_user_id, assigned_lawyer_user_id)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURDATE(), ?, ?, ?, ?)
            ");
            
            $stmt->execute([
                $dosya_no, $case_type, $tc_kimlik, $ad_soyad, $telefon, $kaza_tarihi,
                $plaka ?: null, $karsi_plaka ?: null, $davali_sirket_id, $sigorta_hasar_no ?: null, 
                $current_stage_id, $source_type, $source_name, $sorumlu_user_id, $assigned_lawyer_user_id
            ]);
            
            $case_id = $db->lastInsertId();
            
            // ADK detay
            if ($case_type == 'ADK' && $plaka) {
                $stmt = $db->prepare("INSERT INTO adk_detail (case_id, plaka, karsi_plaka) VALUES (?, ?, ?)");
                $stmt->execute([$case_id, $plaka, $karsi_plaka]);
            }
            
            // Bedeni detay
            if ($case_type == 'BEDENI') {
                $dogum_tarihi = $_POST['dogum_tarihi'] ?? null;
                $adres = trim($_POST['adres'] ?? '');
                $meslek = trim($_POST['meslek'] ?? '');
                $gelir = floatval($_POST['gelir'] ?? 0);
                
                $stmt = $db->prepare("INSERT INTO bedeni_detail (case_id, dogum_tarihi, adres, meslek, gelir) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$case_id, $dogum_tarihi ?: null, $adres ?: null, $meslek ?: null, $gelir ?: null]);
            }
            
            // Aşama geçmişi
            if ($current_stage_id) {
                $stmt = $db->prepare("INSERT INTO case_stage_history (case_id, stage_id, changed_by_user_id) VALUES (?, ?, ?)");
                $stmt->execute([$case_id, $current_stage_id, $_SESSION['user_id']]);
            }
            
            // Audit log
            auditLog('cases', $case_id, 'INSERT');
            
            $db->commit();
            
            $success = "DOSYA BAŞARIYLA OLUŞTURULDU! DOSYA NO: $dosya_no";
            
        } catch (Exception $e) {
            $db->rollBack();
            $error = 'KAYIT HATASI: ' . $e->getMessage();
        }
    }
}

include __DIR__ . '/../includes/header.php';
?>

<div class="page-title"><i class="fas fa-plus-circle"></i> YENİ DOSYA EKLE</div>

<?php if ($error): ?>
<div class="alert alert-error">
    <i class="fas fa-exclamation-circle"></i> <?= e($error) ?>
</div>
<?php endif; ?>

<?php if ($success): ?>
<div class="alert alert-success">
    <i class="fas fa-check-circle"></i> <?= e($success) ?>
</div>
<?php endif; ?>

<form method="POST" class="form-wrap">
    <!-- DOSYA BİLGİLERİ -->
    <div class="form-sec">
        <div class="sec-title"><i class="fas fa-folder"></i> DOSYA BİLGİLERİ</div>
        <div class="form-grid">
            <div class="frm-grp">
                <label class="frm-lbl">DOSYA TÜRÜ <span class="req">*</span></label>
                <select name="case_type" id="case_type" class="frm-sel" required onchange="toggleCaseType()">
                    <option value="">SEÇİNİZ...</option>
                    <option value="ADK" <?= ($_POST['case_type'] ?? '') == 'ADK' ? 'selected' : '' ?>>ADK - ARAÇ DEĞER KAYBI</option>
                    <option value="BEDENI" <?= ($_POST['case_type'] ?? '') == 'BEDENI' ? 'selected' : '' ?>>BEDENİ HASAR</option>
                </select>
            </div>
            <div class="frm-grp">
                <label class="frm-lbl">SİGORTA ŞİRKETİ (DAVALI) <span class="req">*</span></label>
                <select name="davali_sirket_id" class="frm-sel" required>
                    <option value="">SEÇİNİZ...</option>
                    <?php foreach ($sigortalar as $sig): ?>
                    <option value="<?= $sig['id'] ?>" <?= ($_POST['davali_sirket_id'] ?? '') == $sig['id'] ? 'selected' : '' ?>>
                        <?= e($sig['name']) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="frm-grp">
                <label class="frm-lbl">SİGORTA HASAR NO</label>
                <input type="text" name="sigorta_hasar_no" class="frm-in" value="<?= e($_POST['sigorta_hasar_no'] ?? '') ?>" placeholder="SİGORTA HASAR NO">
            </div>
            <div class="frm-grp">
                <label class="frm-lbl">KAZA TARİHİ <span class="req">*</span></label>
                <input type="date" name="kaza_tarihi" class="frm-in" value="<?= e($_POST['kaza_tarihi'] ?? '') ?>" required>
            </div>
            <div class="frm-grp">
                <label class="frm-lbl">BAŞLANGIÇ AŞAMASI</label>
                <select name="current_stage_id" class="frm-sel">
                    <option value="">SEÇİNİZ...</option>
                    <?php foreach ($asamalar as $asama): ?>
                    <option value="<?= $asama['id'] ?>"><?= e($asama['name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="frm-grp">
                <label class="frm-lbl">ATANAN AVUKAT</label>
                <select name="assigned_lawyer_user_id" class="frm-sel">
                    <option value="">SEÇİNİZ...</option>
                    <?php foreach ($avukatlar as $avk): ?>
                    <option value="<?= $avk['id'] ?>"><?= e($avk['full_name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
    </div>
    
    <!-- MAĞDUR BİLGİLERİ -->
    <div class="form-sec">
        <div class="sec-title"><i class="fas fa-user"></i> MAĞDUR BİLGİLERİ</div>
        <div class="form-grid">
            <div class="frm-grp">
                <label class="frm-lbl">T.C. KİMLİK NO <span class="req">*</span></label>
                <input type="text" name="tc_kimlik" class="frm-in" value="<?= e($_POST['tc_kimlik'] ?? '') ?>" maxlength="11" placeholder="11 HANELİ T.C." required>
            </div>
            <div class="frm-grp">
                <label class="frm-lbl">ADI SOYADI <span class="req">*</span></label>
                <input type="text" name="ad_soyad" class="frm-in" value="<?= e($_POST['ad_soyad'] ?? '') ?>" placeholder="ADI SOYADI" required>
            </div>
            <div class="frm-grp">
                <label class="frm-lbl">TELEFON <span class="req">*</span></label>
                <input type="tel" name="telefon" class="frm-in" value="<?= e($_POST['telefon'] ?? '') ?>" placeholder="05XX XXX XX XX" required>
            </div>
        </div>
    </div>
    
    <!-- ADK ARAÇ BİLGİLERİ -->
    <div class="form-sec" id="adk-section" style="display:none">
        <div class="sec-title"><i class="fas fa-car"></i> ARAÇ BİLGİLERİ (ADK)</div>
        <div class="form-grid">
            <div class="frm-grp">
                <label class="frm-lbl">PLAKA <span class="req">*</span></label>
                <input type="text" name="plaka" class="frm-in" value="<?= e($_POST['plaka'] ?? '') ?>" placeholder="34 ABC 123">
            </div>
            <div class="frm-grp">
                <label class="frm-lbl">KARŞI ARAÇ PLAKASI <span class="req">*</span></label>
                <input type="text" name="karsi_plaka" class="frm-in" value="<?= e($_POST['karsi_plaka'] ?? '') ?>" placeholder="34 XYZ 456">
            </div>
        </div>
    </div>
    
    <!-- BEDENİ HASAR EK BİLGİLER -->
    <div class="form-sec" id="bedeni-section" style="display:none">
        <div class="sec-title"><i class="fas fa-user-injured"></i> EK BİLGİLER (BEDENİ HASAR)</div>
        <div class="form-grid">
            <div class="frm-grp">
                <label class="frm-lbl">DOĞUM TARİHİ</label>
                <input type="date" name="dogum_tarihi" class="frm-in" value="<?= e($_POST['dogum_tarihi'] ?? '') ?>">
            </div>
            <div class="frm-grp">
                <label class="frm-lbl">MESLEK</label>
                <input type="text" name="meslek" class="frm-in" value="<?= e($_POST['meslek'] ?? '') ?>" placeholder="MESLEK">
            </div>
            <div class="frm-grp">
                <label class="frm-lbl">AYLIK GELİR (₺)</label>
                <input type="number" name="gelir" class="frm-in" value="<?= e($_POST['gelir'] ?? '') ?>" placeholder="0">
            </div>
            <div class="frm-grp" style="grid-column: span 2">
                <label class="frm-lbl">ADRES</label>
                <textarea name="adres" class="frm-ta" rows="2" placeholder="ADRES"><?= e($_POST['adres'] ?? '') ?></textarea>
            </div>
        </div>
    </div>
    
    <!-- KAYNAK BİLGİLERİ -->
    <div class="form-sec">
        <div class="sec-title"><i class="fas fa-directions"></i> KAYNAK BİLGİLERİ</div>
        <div class="form-grid">
            <div class="frm-grp">
                <label class="frm-lbl">KAYNAK TİPİ <span class="req">*</span></label>
                <select name="source_type" class="frm-sel" required>
                    <option value="">SEÇİNİZ...</option>
                    <option value="SERVIS" <?= ($_POST['source_type'] ?? '') == 'SERVIS' ? 'selected' : '' ?>>SERVİS</option>
                    <option value="YONLENDIREN" <?= ($_POST['source_type'] ?? '') == 'YONLENDIREN' ? 'selected' : '' ?>>YÖNLENDİREN</option>
                    <option value="OFIS_CRM" <?= ($_POST['source_type'] ?? '') == 'OFIS_CRM' ? 'selected' : '' ?>>OFİS CRM</option>
                    <option value="SAHA" <?= ($_POST['source_type'] ?? '') == 'SAHA' ? 'selected' : '' ?>>SAHA</option>
                    <option value="MR" <?= ($_POST['source_type'] ?? '') == 'MR' ? 'selected' : '' ?>>MR</option>
                </select>
            </div>
            <div class="frm-grp">
                <label class="frm-lbl">KAYNAK ADI</label>
                <input type="text" name="source_name" class="frm-in" value="<?= e($_POST['source_name'] ?? '') ?>" placeholder="KAYNAK ADI">
            </div>
            <div class="frm-grp">
                <label class="frm-lbl">DOSYA SORUMLUSU</label>
                <select name="sorumlu_user_id" class="frm-sel">
                    <?php foreach ($sorumlular as $sor): ?>
                    <option value="<?= $sor['id'] ?>" <?= ($_POST['sorumlu_user_id'] ?? ($_SESSION['user_id'] ?? '')) == $sor['id'] ? 'selected' : '' ?>>
                        <?= e($sor['full_name']) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>
    </div>
    
    <div class="form-act">
        <a href="dosyalar.php" class="btn btn-sec">
            <i class="fas fa-times"></i> İPTAL
        </a>
        <button type="submit" class="btn btn-suc">
            <i class="fas fa-save"></i> KAYDET
        </button>
    </div>
</form>

<script>
function toggleCaseType() {
    const type = document.getElementById('case_type').value;
    document.getElementById('adk-section').style.display = type === 'ADK' ? 'block' : 'none';
    document.getElementById('bedeni-section').style.display = type === 'BEDENI' ? 'block' : 'none';
}
document.addEventListener('DOMContentLoaded', toggleCaseType);
</script>

<?php include __DIR__ . '/../includes/footer.php'; ?>

<?php
/**
 * MR HASAR DANIŞMANLIK - DASHBOARD
 * EXCELLENCE DISTINGUISHES US ALWAYS
 */

// Hata gösterimi (geçici)
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../config.php';

try {
    $db = getDB();
    
    // İstatistikler
    $stats = [];
    
    // Toplam dosya
    $stmt = $db->query("SELECT COUNT(*) as total FROM cases");
    $stats['total'] = $stmt->fetch()['total'] ?? 0;
    
    // Aktif dosya
    $stmt = $db->query("SELECT COUNT(*) as aktif FROM cases WHERE status = 'AKTIF'");
    $stats['aktif'] = $stmt->fetch()['aktif'] ?? 0;
    
    // Kapalı dosya
    $stmt = $db->query("SELECT COUNT(*) as kapali FROM cases WHERE status = 'KAPALI'");
    $stats['kapali'] = $stmt->fetch()['kapali'] ?? 0;
    
    // ADK dosya
    $stmt = $db->query("SELECT COUNT(*) as adk FROM cases WHERE case_type = 'ADK'");
    $stats['adk'] = $stmt->fetch()['adk'] ?? 0;
    
    // Bedeni dosya
    $stmt = $db->query("SELECT COUNT(*) as bedeni FROM cases WHERE case_type = 'BEDENI'");
    $stats['bedeni'] = $stmt->fetch()['bedeni'] ?? 0;
    
    // Aylık gelir
    $stmt = $db->query("SELECT COALESCE(SUM(amount), 0) as gelir FROM finance_transactions WHERE txn_type = 'GELIR' AND MONTH(txn_date) = MONTH(CURRENT_DATE()) AND YEAR(txn_date) = YEAR(CURRENT_DATE())");
    $stats['aylik_gelir'] = $stmt->fetch()['gelir'] ?? 0;
    
    // Son dosyalar
    $stmt = $db->query("
        SELECT c.*, 
               i.name as sigorta_adi, 
               s.name as asama_adi, 
               u.full_name as sorumlu_adi
        FROM cases c
        LEFT JOIN insurers i ON c.davali_sirket_id = i.id
        LEFT JOIN stage_definitions s ON c.current_stage_id = s.id
        LEFT JOIN users u ON c.sorumlu_user_id = u.id
        ORDER BY c.created_at DESC
        LIMIT 10
    ");
    $sonDosyalar = $stmt->fetchAll();
    
} catch (Exception $e) {
    $error = $e->getMessage();
    $stats = ['total' => 0, 'aktif' => 0, 'kapali' => 0, 'adk' => 0, 'bedeni' => 0, 'aylik_gelir' => 0];
    $sonDosyalar = [];
}

include __DIR__ . '/../includes/header.php';
?>

<?php if (isset($error)): ?>
<div class="alert alert-error">
    <i class="fas fa-exclamation-circle"></i> VERİTABANI HATASI: <?= e($error) ?>
</div>
<?php endif; ?>

<div class="page-title"><i class="fas fa-tachometer-alt"></i> KONTROL PANELİ</div>

<!-- İSTATİSTİK KARTLARI -->
<div class="cards">
    <div class="card">
        <div class="card-head">
            <div class="card-icon blue"><i class="fas fa-folder-open"></i></div>
            <div>
                <div class="card-title">TOPLAM DOSYA</div>
                <div class="card-val"><?= number_format($stats['total']) ?></div>
            </div>
        </div>
    </div>
    <div class="card">
        <div class="card-head">
            <div class="card-icon green"><i class="fas fa-check-circle"></i></div>
            <div>
                <div class="card-title">AKTİF DOSYA</div>
                <div class="card-val"><?= number_format($stats['aktif']) ?></div>
            </div>
        </div>
    </div>
    <div class="card">
        <div class="card-head">
            <div class="card-icon orange"><i class="fas fa-clock"></i></div>
            <div>
                <div class="card-title">KAPALI DOSYA</div>
                <div class="card-val"><?= number_format($stats['kapali']) ?></div>
            </div>
        </div>
    </div>
    <div class="card">
        <div class="card-head">
            <div class="card-icon purple"><i class="fas fa-car-crash"></i></div>
            <div>
                <div class="card-title">ADK DOSYA</div>
                <div class="card-val"><?= number_format($stats['adk']) ?></div>
            </div>
        </div>
    </div>
    <div class="card">
        <div class="card-head">
            <div class="card-icon cyan"><i class="fas fa-user-injured"></i></div>
            <div>
                <div class="card-title">BEDENİ HASAR</div>
                <div class="card-val"><?= number_format($stats['bedeni']) ?></div>
            </div>
        </div>
    </div>
    <div class="card">
        <div class="card-head">
            <div class="card-icon green"><i class="fas fa-lira-sign"></i></div>
            <div>
                <div class="card-title">AYLIK GELİR</div>
                <div class="card-val">₺<?= number_format($stats['aylik_gelir'], 0, ',', '.') ?></div>
            </div>
        </div>
    </div>
</div>

<!-- HIZLI İŞLEMLER -->
<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px;margin-bottom:25px">
    <a href="dosya_ekle.php" class="btn btn-suc" style="justify-content:center;padding:14px">
        <i class="fas fa-plus-circle"></i> YENİ DOSYA
    </a>
    <a href="dosyalar.php" class="btn btn-pri" style="justify-content:center;padding:14px">
        <i class="fas fa-list"></i> DOSYALAR
    </a>
    <a href="crm.php" class="btn btn-war" style="justify-content:center;padding:14px">
        <i class="fas fa-headset"></i> CRM
    </a>
    <a href="rapor_finansal.php" class="btn btn-sec" style="justify-content:center;padding:14px">
        <i class="fas fa-chart-bar"></i> RAPORLAR
    </a>
</div>

<!-- SON DOSYALAR -->
<div class="panel">
    <div class="panel-head">
        <div class="panel-title"><i class="fas fa-history"></i> SON DOSYALAR</div>
        <a href="dosyalar.php" class="btn btn-sec">
            <i class="fas fa-list"></i> TÜMÜNÜ GÖR
        </a>
    </div>
    <div class="tbl-wrap">
        <table>
            <thead>
                <tr>
                    <th>DOSYA NO</th>
                    <th>T.C.</th>
                    <th>ADI SOYADI</th>
                    <th>TÜR</th>
                    <th>SİGORTA</th>
                    <th>AŞAMA</th>
                    <th>SORUMLU</th>
                    <th>TARİH</th>
                    <th>İŞLEM</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($sonDosyalar)): ?>
                <tr>
                    <td colspan="9" style="text-align:center;padding:30px;color:var(--text2)">
                        <i class="fas fa-folder-open" style="font-size:30px;margin-bottom:10px;display:block"></i>
                        HENÜZ DOSYA BULUNMUYOR
                    </td>
                </tr>
                <?php else: ?>
                <?php foreach ($sonDosyalar as $dosya): ?>
                <tr>
                    <td style="color:var(--blue);font-weight:700"><?= e($dosya['dosya_no']) ?></td>
                    <td><?= substr($dosya['tc_kimlik'], 0, 3) ?>***<?= substr($dosya['tc_kimlik'], -3) ?></td>
                    <td><?= e($dosya['ad_soyad']) ?></td>
                    <td><span class="badge <?= strtolower($dosya['case_type']) ?>"><?= e($dosya['case_type']) ?></span></td>
                    <td><?= e($dosya['sigorta_adi'] ?? '-') ?></td>
                    <td><span class="badge aktif"><?= e($dosya['asama_adi'] ?? '-') ?></span></td>
                    <td><?= e($dosya['sorumlu_adi'] ?? '-') ?></td>
                    <td><?= $dosya['acilis_tarihi'] ? date('d.m.Y', strtotime($dosya['acilis_tarihi'])) : '-' ?></td>
                    <td>
                        <div class="icons">
                            <a href="dosya_detay.php?id=<?= $dosya['id'] ?>" class="ic view"><i class="fas fa-eye"></i></a>
                            <a href="dosya_duzenle.php?id=<?= $dosya['id'] ?>" class="ic edit"><i class="fas fa-edit"></i></a>
                            <a href="dosya_evrak.php?id=<?= $dosya['id'] ?>" class="ic doc"><i class="fas fa-file-alt"></i></a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>

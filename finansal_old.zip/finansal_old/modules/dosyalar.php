<?php
/**
 * MR HASAR DANIŞMANLIK - DOSYA LİSTELEME
 * EXCELLENCE DISTINGUISHES US ALWAYS
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../config.php';

try {
    $db = getDB();
    
    // Filtreler
    $where = "1=1";
    $params = [];
    
    if (!empty($_GET['dosya_no'])) {
        $where .= " AND c.dosya_no LIKE ?";
        $params[] = '%' . $_GET['dosya_no'] . '%';
    }
    
    if (!empty($_GET['ad_soyad'])) {
        $where .= " AND c.ad_soyad LIKE ?";
        $params[] = '%' . $_GET['ad_soyad'] . '%';
    }
    
    if (!empty($_GET['case_type'])) {
        $where .= " AND c.case_type = ?";
        $params[] = $_GET['case_type'];
    }
    
    if (!empty($_GET['status'])) {
        $where .= " AND c.status = ?";
        $params[] = $_GET['status'];
    }
    
    // Sayfalama
    $page = max(1, intval($_GET['page'] ?? 1));
    $perPage = 20;
    $offset = ($page - 1) * $perPage;
    
    // Toplam kayıt
    $countStmt = $db->prepare("SELECT COUNT(*) as total FROM cases c WHERE $where");
    $countStmt->execute($params);
    $totalRecords = $countStmt->fetch()['total'];
    $totalPages = ceil($totalRecords / $perPage);
    
    // Dosyaları getir
    $sql = "
        SELECT c.*, i.name as sigorta_adi, s.name as asama_adi, 
               u.full_name as sorumlu_adi, a.full_name as avukat_adi
        FROM cases c
        LEFT JOIN insurers i ON c.davali_sirket_id = i.id
        LEFT JOIN stage_definitions s ON c.current_stage_id = s.id
        LEFT JOIN users u ON c.sorumlu_user_id = u.id
        LEFT JOIN users a ON c.assigned_lawyer_user_id = a.id
        WHERE $where
        ORDER BY c.created_at DESC
        LIMIT $perPage OFFSET $offset
    ";
    
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $dosyalar = $stmt->fetchAll();
    
} catch (Exception $e) {
    $error = $e->getMessage();
    $dosyalar = [];
    $totalRecords = 0;
    $totalPages = 0;
}

include __DIR__ . '/../includes/header.php';
?>

<div class="page-title"><i class="fas fa-list"></i> DOSYA LİSTELEME</div>

<?php if (isset($error)): ?>
<div class="alert alert-error">
    <i class="fas fa-exclamation-circle"></i> HATA: <?= e($error) ?>
</div>
<?php endif; ?>

<!-- FİLTRE -->
<form method="GET" class="filter">
    <div class="filter-grid">
        <div class="f-group">
            <label class="f-label">DOSYA NO</label>
            <input type="text" name="dosya_no" class="f-input" value="<?= e($_GET['dosya_no'] ?? '') ?>" placeholder="DOSYA NO">
        </div>
        <div class="f-group">
            <label class="f-label">ADI SOYADI</label>
            <input type="text" name="ad_soyad" class="f-input" value="<?= e($_GET['ad_soyad'] ?? '') ?>" placeholder="ADI SOYADI">
        </div>
        <div class="f-group">
            <label class="f-label">DOSYA TÜRÜ</label>
            <select name="case_type" class="f-select">
                <option value="">TÜMÜ</option>
                <option value="ADK" <?= ($_GET['case_type'] ?? '') == 'ADK' ? 'selected' : '' ?>>ADK</option>
                <option value="BEDENI" <?= ($_GET['case_type'] ?? '') == 'BEDENI' ? 'selected' : '' ?>>BEDENİ</option>
            </select>
        </div>
        <div class="f-group">
            <label class="f-label">DURUM</label>
            <select name="status" class="f-select">
                <option value="">TÜMÜ</option>
                <option value="AKTIF" <?= ($_GET['status'] ?? '') == 'AKTIF' ? 'selected' : '' ?>>AKTİF</option>
                <option value="KAPALI" <?= ($_GET['status'] ?? '') == 'KAPALI' ? 'selected' : '' ?>>KAPALI</option>
            </select>
        </div>
        <div class="f-group" style="display:flex;align-items:flex-end;gap:8px">
            <button type="submit" class="btn btn-suc" style="flex:1">
                <i class="fas fa-search"></i> ARA
            </button>
            <a href="dosyalar.php" class="btn btn-sec">
                <i class="fas fa-times"></i>
            </a>
        </div>
    </div>
</form>

<!-- DOSYA LİSTESİ -->
<div class="panel">
    <div class="panel-head">
        <div class="panel-title">
            <span style="color:var(--blue);font-size:14px"><?= number_format($totalRecords) ?></span> KAYIT BULUNDU
        </div>
        <a href="dosya_ekle.php" class="btn btn-suc">
            <i class="fas fa-plus"></i> YENİ DOSYA
        </a>
    </div>
    <div class="tbl-wrap">
        <table>
            <thead>
                <tr>
                    <th>DOSYA NO</th>
                    <th>ADI SOYADI</th>
                    <th>DOSYA TÜRÜ</th>
                    <th>DAVALI ŞİRKET</th>
                    <th>DOSYA AŞAMASI</th>
                    <th>AVUKAT</th>
                    <th>AÇILIŞ TARİHİ</th>
                    <th>İŞLEM</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($dosyalar)): ?>
                <tr>
                    <td colspan="8" style="text-align:center;padding:30px;color:var(--text2)">
                        <i class="fas fa-folder-open" style="font-size:30px;margin-bottom:10px;display:block"></i>
                        KAYIT BULUNAMADI
                    </td>
                </tr>
                <?php else: ?>
                <?php foreach ($dosyalar as $dosya): ?>
                <tr>
                    <td style="color:var(--blue);font-weight:700"><?= e($dosya['dosya_no']) ?></td>
                    <td><?= e($dosya['ad_soyad']) ?></td>
                    <td><span class="badge <?= strtolower($dosya['case_type']) ?>"><?= e($dosya['case_type']) ?></span></td>
                    <td><?= e($dosya['sigorta_adi'] ?? '-') ?></td>
                    <td><span class="badge aktif"><?= e($dosya['asama_adi'] ?? '-') ?></span></td>
                    <td><?= e($dosya['avukat_adi'] ?? '-') ?></td>
                    <td><?= $dosya['acilis_tarihi'] ? date('d.m.Y', strtotime($dosya['acilis_tarihi'])) : '-' ?></td>
                    <td>
                        <div class="icons">
                            <a href="dosya_detay.php?id=<?= $dosya['id'] ?>" class="ic view" title="DETAY"><i class="fas fa-eye"></i></a>
                            <a href="dosya_duzenle.php?id=<?= $dosya['id'] ?>" class="ic edit" title="DÜZENLE"><i class="fas fa-edit"></i></a>
                            <a href="dosya_evrak.php?id=<?= $dosya['id'] ?>" class="ic doc" title="EVRAKLAR"><i class="fas fa-file-alt"></i></a>
                        </div>
                    </td>
                </tr>
                <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    
    <?php if ($totalPages > 1): ?>
    <div class="pagination">
        <?php if ($page > 1): ?>
        <a href="?page=<?= $page - 1 ?>&<?= http_build_query(array_diff_key($_GET, ['page' => ''])) ?>">
            <i class="fas fa-chevron-left"></i>
        </a>
        <?php endif; ?>
        
        <?php for ($i = max(1, $page - 2); $i <= min($totalPages, $page + 2); $i++): ?>
        <a href="?page=<?= $i ?>&<?= http_build_query(array_diff_key($_GET, ['page' => ''])) ?>" class="<?= $i == $page ? 'active' : '' ?>">
            <?= $i ?>
        </a>
        <?php endfor; ?>
        
        <?php if ($page < $totalPages): ?>
        <a href="?page=<?= $page + 1 ?>&<?= http_build_query(array_diff_key($_GET, ['page' => ''])) ?>">
            <i class="fas fa-chevron-right"></i>
        </a>
        <?php endif; ?>
    </div>
    <?php endif; ?>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>

/**
 * MR HASAR DANIŞMANLIK - ANA JAVASCRIPT
 * CPANEL PHP + MYSQL V2.0
 * EXCELLENCE DISTINGUISHES US ALWAYS
 */

// Bildirim göster
function showNotification(message, type = 'info') {
    const existing = document.querySelector('.notification');
    if (existing) existing.remove();
    
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
        <span>${message}</span>
    `;
    
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 15px 25px;
        border-radius: 10px;
        display: flex;
        align-items: center;
        gap: 10px;
        font-size: 11px;
        font-weight: 600;
        z-index: 99999;
        animation: slideIn 0.3s ease;
        text-transform: uppercase;
        ${type === 'success' ? 'background: linear-gradient(135deg, #10b981, #059669); color: white;' : ''}
        ${type === 'error' ? 'background: linear-gradient(135deg, #ef4444, #dc2626); color: white;' : ''}
        ${type === 'info' ? 'background: linear-gradient(135deg, #3b82f6, #1d4ed8); color: white;' : ''}
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Onay kutusu
function confirmAction(message, callback) {
    if (confirm(message)) {
        callback();
    }
}

// Para formatla
function formatCurrency(amount) {
    return new Intl.NumberFormat('tr-TR', {
        style: 'currency',
        currency: 'TRY',
        minimumFractionDigits: 0
    }).format(amount);
}

// Tarih formatla
function formatDate(date) {
    return new Date(date).toLocaleDateString('tr-TR');
}

// TC Kimlik doğrulama
function validateTCKimlik(tc) {
    if (!/^[0-9]{11}$/.test(tc)) return false;
    if (tc[0] === '0') return false;
    
    let odd = 0, even = 0, total = 0;
    
    for (let i = 0; i < 9; i++) {
        const digit = parseInt(tc[i]);
        total += digit;
        if (i % 2 === 0) odd += digit;
        else even += digit;
    }
    
    let digit10 = (odd * 7 - even) % 10;
    if (digit10 < 0) digit10 += 10;
    
    const digit11 = (total + digit10) % 10;
    
    return parseInt(tc[9]) === digit10 && parseInt(tc[10]) === digit11;
}

// Telefon formatla
function formatPhone(input) {
    let value = input.value.replace(/\D/g, '');
    
    if (value.length > 0) {
        if (value.length <= 4) {
            value = value;
        } else if (value.length <= 7) {
            value = value.slice(0, 4) + ' ' + value.slice(4);
        } else {
            value = value.slice(0, 4) + ' ' + value.slice(4, 7) + ' ' + value.slice(7, 9) + ' ' + value.slice(9, 11);
        }
    }
    
    input.value = value;
}

// Plaka formatla
function formatPlaka(input) {
    let value = input.value.toUpperCase().replace(/[^A-Z0-9]/g, '');
    input.value = value;
}

// Silme onayı
function confirmDelete(message, url) {
    if (confirm(message || 'BU KAYDI SİLMEK İSTEDİĞİNİZE EMİN MİSİNİZ?')) {
        window.location.href = url;
    }
}

// Sayfa yüklendiğinde
document.addEventListener('DOMContentLoaded', function() {
    // Animation keyframes ekle
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        @keyframes slideOut {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(100%); opacity: 0; }
        }
    `;
    document.head.appendChild(style);
    
    console.log(`
╔══════════════════════════════════════════╗
║     MR HASAR DANIŞMANLIK                 ║
║     FİNANSAL YÖNETİM SİSTEMİ V2.0        ║
║                                          ║
║     EXCELLENCE DISTINGUISHES US ALWAYS   ║
╚══════════════════════════════════════════╝
    `);
});

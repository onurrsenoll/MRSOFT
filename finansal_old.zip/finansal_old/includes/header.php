<?php
/**
 * MR HASAR DANIŞMANLIK - HEADER
 * EXCELLENCE DISTINGUISHES US ALWAYS
 */

if (!defined('APP_NAME')) {
    require_once __DIR__ . '/../config.php';
}
startSecureSession();

if (!isLoggedIn()) {
    header('Location: ../index.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= APP_NAME ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="../css/style.css" rel="stylesheet">
    <style>
    /* DROPDOWN FIX */
    .nav-item {
        position: relative;
    }
    .dropdown {
        position: absolute;
        top: 100%;
        left: 0;
        background: #111d35;
        border: 1px solid #2a3f5f;
        border-radius: 10px;
        min-width: 240px;
        box-shadow: 0 15px 50px rgba(0,0,0,0.6);
        opacity: 0;
        visibility: hidden;
        transform: translateY(-10px);
        transition: all 0.25s ease;
        z-index: 99999;
        padding: 8px 0;
    }
    .nav-item:hover > .dropdown {
        opacity: 1;
        visibility: visible;
        transform: translateY(0);
    }
    .drop-item {
        display: block;
        padding: 12px 18px;
        font-size: 10px;
        color: #94a3b8;
        cursor: pointer;
        transition: all 0.2s;
        text-decoration: none;
        text-transform: uppercase;
    }
    .drop-item:hover {
        background: rgba(59, 130, 246, 0.15);
        color: #ffffff;
        padding-left: 24px;
    }
    .drop-item i {
        width: 22px;
        margin-right: 10px;
        color: #3b82f6;
        font-size: 11px;
    }
    .drop-div {
        height: 1px;
        background: #2a3f5f;
        margin: 6px 0;
    }
    </style>
</head>
<body>
    <!-- HEADER -->
    <div class="header">
        <div>
            <div class="logo"><?= APP_NAME ?></div>
            <div class="slogan"><?= APP_SLOGAN ?></div>
        </div>
        <div class="user-sec">
            <div style="text-align:right">
                <div class="user-name"><?= e($_SESSION['user_name'] ?? 'KULLANICI') ?></div>
                <div class="user-role"><?= e($_SESSION['user_role'] ?? '') ?></div>
            </div>
            <a href="../index.php?logout=1" class="logout-btn">
                <i class="fas fa-sign-out-alt"></i> ÇIKIŞ
            </a>
        </div>
    </div>
    
    <!-- NAVİGASYON -->
    <nav class="nav">
        <!-- ANASAYFA -->
        <a href="dashboard.php" class="nav-item">
            <i class="fas fa-home"></i> ANASAYFA
        </a>
        
        <!-- DOSYA İŞLEMLERİ -->
        <div class="nav-item">
            <i class="fas fa-folder-open"></i> DOSYA İŞLEMLERİ
            <i class="fas fa-chevron-down" style="font-size:8px;margin-left:4px"></i>
            <div class="dropdown">
                <a href="dosyalar.php" class="drop-item">
                    <i class="fas fa-list"></i> DOSYALARI LİSTELE
                </a>
                <a href="dosya_ekle.php" class="drop-item">
                    <i class="fas fa-plus-circle"></i> YENİ DOSYA EKLE
                </a>
                <div class="drop-div"></div>
                <a href="crm.php" class="drop-item">
                    <i class="fas fa-headset"></i> CRM
                </a>
            </div>
        </div>
        
        <!-- ORTAKLAR -->
        <div class="nav-item">
            <i class="fas fa-users"></i> ORTAKLAR
            <i class="fas fa-chevron-down" style="font-size:8px;margin-left:4px"></i>
            <div class="dropdown">
                <a href="ortaklar.php" class="drop-item">
                    <i class="fas fa-list-alt"></i> LİSTELE / EKLE / GÜNCELLE
                </a>
                <a href="ortak_hesaplari.php" class="drop-item">
                    <i class="fas fa-calculator"></i> ORTAK HESAPLARI
                </a>
            </div>
        </div>
        
        <!-- RAPORLAR -->
        <div class="nav-item">
            <i class="fas fa-chart-bar"></i> RAPORLAR
            <i class="fas fa-chevron-down" style="font-size:8px;margin-left:4px"></i>
            <div class="dropdown">
                <a href="rapor_dosya.php" class="drop-item">
                    <i class="fas fa-file-alt"></i> DOSYA DETAY RAPORU
                </a>
                <a href="rapor_finansal.php" class="drop-item">
                    <i class="fas fa-coins"></i> FİNANSAL ÖZET
                </a>
                <a href="rapor_ortak.php" class="drop-item">
                    <i class="fas fa-handshake"></i> İŞ ORTAKLARI RAPORU
                </a>
            </div>
        </div>
        
        <!-- HESAPLAMA -->
        <div class="nav-item">
            <i class="fas fa-calculator"></i> HESAPLAMA
            <i class="fas fa-chevron-down" style="font-size:8px;margin-left:4px"></i>
            <div class="dropdown">
                <a href="hesap_adk.php" class="drop-item">
                    <i class="fas fa-car-crash"></i> ARAÇ DEĞER KAYBI
                </a>
                <a href="hesap_maluliyet.php" class="drop-item">
                    <i class="fas fa-wheelchair"></i> SAKATLIK AKTÜERYA
                </a>
            </div>
        </div>
        
        <!-- TANIMLAMALAR -->
        <div class="nav-item">
            <i class="fas fa-cogs"></i> TANIMLAMALAR
            <i class="fas fa-chevron-down" style="font-size:8px;margin-left:4px"></i>
            <div class="dropdown">
                <a href="tanim_personel.php" class="drop-item">
                    <i class="fas fa-id-card"></i> PERSONEL
                </a>
                <a href="tanim_sigorta.php" class="drop-item">
                    <i class="fas fa-building"></i> SİGORTA ŞİRKETLERİ
                </a>
            </div>
        </div>
        
        <!-- MUHASEBE -->
        <div class="nav-item">
            <i class="fas fa-wallet"></i> MUHASEBE
            <i class="fas fa-chevron-down" style="font-size:8px;margin-left:4px"></i>
            <div class="dropdown">
                <a href="kasa.php" class="drop-item">
                    <i class="fas fa-cash-register"></i> KASALAR
                </a>
                <a href="cari.php" class="drop-item">
                    <i class="fas fa-address-book"></i> CARİLER
                </a>
                <div class="drop-div"></div>
                <a href="gelir_gider.php" class="drop-item">
                    <i class="fas fa-exchange-alt"></i> GELİR / GİDER
                </a>
            </div>
        </div>
        
        <!-- SİSTEM -->
        <?php if (hasRole(['ADMIN'])): ?>
        <div class="nav-item">
            <i class="fas fa-sliders-h"></i> SİSTEM
            <i class="fas fa-chevron-down" style="font-size:8px;margin-left:4px"></i>
            <div class="dropdown">
                <a href="sistem_genel.php" class="drop-item">
                    <i class="fas fa-cog"></i> GENEL YÖNETİM
                </a>
                <a href="sistem_asama.php" class="drop-item">
                    <i class="fas fa-tasks"></i> AŞAMA YÖNETİMİ
                </a>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- MESAJLAR -->
        <a href="mesajlar.php" class="nav-item">
            <i class="fas fa-envelope"></i> MESAJLAR
        </a>
        
        <!-- AJANDA -->
        <a href="ajanda.php" class="nav-item">
            <i class="fas fa-calendar-alt"></i> AJANDA
        </a>
    </nav>
    
    <!-- MAIN CONTENT START -->
    <main class="content">

<?php
declare(strict_types=1);

/**
 * MR HASAR DANIŞMANLIK - FİNANSAL
 * CONFIG.PHP (CPANEL UYUMLU)
 *
 * NOT: BU DOSYADA PHP AÇILIŞ ETİKETİNDEN (<?php) ÖNCE HİÇBİR KARAKTER/BOŞLUK/BOM OLMAMALIDIR.
 */

// =====================
// VERİTABANI AYARLARI
// =====================
define('DB_HOST', 'localhost');              // cPanel'de genelde localhost
define('DB_NAME', 'mrhasard_finansal');      // SENİN DB ADIN
define('DB_USER', 'mrhasard_finansal');      // SENİN DB USER
define('DB_PASS', 'MrFinans2026');           // SENİN DB ŞİFREN

// =====================
// GENEL AYARLAR
// =====================
date_default_timezone_set('Europe/Istanbul');

ini_set('display_errors', '0');              // PROD
ini_set('log_errors', '1');
error_reporting(E_ALL);

// UYGULAMA KÖK DİZİNİ
define('APP_ROOT', __DIR__);
define('BASE_URL', '/finansal');             // public_html/finansal için

// UPLOADS
define('UPLOAD_DIR', APP_ROOT . '/uploads');

// JSON ÇIKTI İÇİN YARDIMCI
function json_out(array $payload, int $httpCode = 200): void {
    http_response_code($httpCode);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

// PDO BAĞLANTISI (GLOBAL)
try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
} catch (Throwable $e) {
    // PROD'DA DETAY BASMA
    json_out(['success' => false, 'message' => 'VERİTABANI BAĞLANTI HATASI'], 500);
}
